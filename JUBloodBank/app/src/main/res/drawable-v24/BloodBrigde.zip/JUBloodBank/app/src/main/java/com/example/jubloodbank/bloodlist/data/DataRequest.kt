package com.example.jubloodbank.bloodlist.data

data class DataRequest(
    var patient: String? = null,
    var Blood: String? = null,
    var amuont: String? = null,
    var Date: String? = null,
    var Time: String? = null,
    var Hname: String? = null,
    var Location: String? = null,
    var personName: String? = null,
    var phone: String? = null,
    var note: String? = null
)
