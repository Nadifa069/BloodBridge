package com.example.jubloodbank.registration

data class User(

    var name:String,
    var email:String,
    var phone:String,
    var hallName:String?=null,
    var batch:String?=null,
    var Blood:String?=null,
    var id:String?=null


)
