package com.example.jubloodbank.messageservice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.jubloodbank.R

class MessageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)
    }
}